# Virtual RAM simulation logic
