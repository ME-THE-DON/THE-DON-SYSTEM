# Firebase upload placeholder
