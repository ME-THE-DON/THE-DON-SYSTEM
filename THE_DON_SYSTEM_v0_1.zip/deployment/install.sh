# Shell script for one-click installation
