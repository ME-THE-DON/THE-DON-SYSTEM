# Universal browser logic
