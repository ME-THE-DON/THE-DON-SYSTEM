# Offline P2P communication using libp2p or LoRa
